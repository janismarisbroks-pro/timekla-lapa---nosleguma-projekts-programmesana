# timekla-lapa---nosleguma-projekts-programmesana
Autori: Jānis Māris Broks, Jūlija Beikmane, Pauls Ikvilds, Reinis Krēsliņš.
